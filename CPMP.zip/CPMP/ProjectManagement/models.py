from django.db import models

# Create your models here.
class Employee_Model(models.Model):
    name=models.CharField(max_length=200)
    email=models.EmailField(blank=True,null=True,max_length=200)
    doj=models.DateField(blank=True,null=True)
    department_name=models.CharField(max_length=200)

class Department(models.Model):
    project_maneger=models.CharField(max_length=200)
    project_email=models.EmailField(blank=True,null=True,max_length=200)

class project_model(models.Model):
    project_name=models.CharField(max_length=400)
    project_startdate=models.DateField(blank=True,null=True)
    project_enddate=models.DateField(blank=True,null=True)
    project_maneger_name=models.CharField(max_length=200)
    project_maneger_email=models.EmailField(blank=True,null=True,max_length=200)

class Project_Details(models.Model):
    employee_name=models.CharField(max_length=200)
    project_name=models.CharField(max_length=200)
    project_maneger_name=models.CharField(max_length=200)