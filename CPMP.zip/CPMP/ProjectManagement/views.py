from django.shortcuts import render
from django.views import View
from django.http import JsonResponse
from .models import Employee_Model,Department,project_model,Project_Details
import json
# Create your views here.

class HomePage(View):
    template_name="home.html"
    def get(self, request):
        data=Project_Details.objects.all()
        print(data)
        return render(request,self.template_name,{"data":data})


class Emplyee_data(View):
    template_name="empdata.html"
    def get(self,request):
        data=Employee_Model.objects.all()
        return render(request,self.template_name,{"data":data})


class Add_Project(View):
    template_name="addproject.html"
    def get(self,request):
        data=project_model.objects.all()
       
        return render(request,self.template_name,{"data":data})

class Asign_project(View):
    template_name="assignproject.html"
    def get(self,request):
        data=Employee_Model.objects.all()
        data1=project_model.objects.all()
        return render(request,self.template_name,{"data":data,"data1":data1})

class Save_Emplyee(View):
    def post(self,request):
        if request.method=="POST":
                name = request.POST.get("name")
                print(name)
                email = request.POST.get("email")
                print(email)
                doj = request.POST.get("doj")
                print(doj)
                department_name = request.POST.get("department_name")
                print(department_name)
                empdata=Employee_Model(name=name,email=email,doj=doj,department_name=department_name)
                empdata.save()
                return JsonResponse({"status":"Save"})
        else:
            return JsonResponse({"status":1})

class Save_Project(View):
    def post(self,request):
        if request.method=="POST":
                project_name = request.POST.get("project_name")
                print(project_name)
                project_startdate = request.POST.get("project_startdate")
                print(project_startdate)
                project_enddate = request.POST.get("project_enddate")
                print(project_enddate)
                project_maneger_name = request.POST.get("project_maneger_name")
                print(project_maneger_name)
                project_maneger_email = request.POST.get("project_maneger_email")
                print(project_maneger_email)
                empdata=project_model(project_name=project_name,project_startdate=project_startdate,project_enddate=project_enddate,project_maneger_name=project_maneger_name,project_maneger_email=project_maneger_email)
                empdata.save()
                return JsonResponse({"status":"Save"})
        else:
            return JsonResponse({"status":"Faield"})

class Asign_save(View):
    def post(self,request):
        if request.method=="POST":
                employee_name = request.POST.get("employee_name")
                print(employee_name)
                project_name = request.POST.get("project_name")
                print(project_name)
                project_maneger_name = request.POST.get("project_maneger_name")
                print(project_maneger_name)
                
                empdata=Project_Details(employee_name=employee_name,project_name=project_name,project_maneger_name=project_maneger_name)
                empdata.save()
                return JsonResponse({"status":"Save"})
        else:
            return JsonResponse({"status":"Faield"})

class Assigndataon(View):
    template_name="showdata.html"
    def get(self,request,id):
        print(id)
        data2=Employee_Model.objects.get(id=2)
        print(data2)
        return render(request,self.template_name,{"data2":data2})


class AssignPRO(View):
    template_name="showprojectdata.html"
    def get(self,request,id):
        print(id)
        data3=project_model.objects.get(id=id)
        print(data3)
        return render(request,self.template_name,{"data3":data3})