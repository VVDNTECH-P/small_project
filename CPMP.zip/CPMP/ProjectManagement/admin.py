from django.contrib import admin
from .models import Employee_Model,Department,project_model,Project_Details
# Register your models here.
@admin.register(Employee_Model)
class EmpModelAdmin(admin.ModelAdmin):
    list_display=["id","name", "email","doj","department_name"]

@admin.register(Department)
class DepartmentModelAdmin(admin.ModelAdmin):
    list_display=["project_maneger", "project_email"]

@admin.register(project_model)
class ProjectModelAdmin(admin.ModelAdmin):
    list_display=["id","project_name", "project_startdate","project_enddate","project_maneger_name","project_maneger_email"]

@admin.register(Project_Details)
class ProjectdetailsModelAdmin(admin.ModelAdmin):
    list_display=["employee_name", "project_name","project_maneger_name"]


