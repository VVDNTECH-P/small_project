from django.urls import path
from  . import views
urlpatterns = [
    path("",views.HomePage.as_view(),name="home"),
    path("emp",views.Emplyee_data.as_view(),name="emp"),
    path("addproject",views.Add_Project.as_view(),name="addpro"),
    path("saveemp",views.Save_Emplyee.as_view(),name="saveemp"),
    path("savepro",views.Save_Project.as_view(),name="saveproject"),
    path("assignpro",views.Asign_project.as_view(),name="asignproject"),
    path("assigsave",views.Asign_save.as_view(),name="saveassign"),
    path("dataon/<int:id>/",views.Assigndataon.as_view(),name="dataon"),
    path("dataPRO/<int:id>/",views.AssignPRO.as_view(),name="dataPRO")

]
