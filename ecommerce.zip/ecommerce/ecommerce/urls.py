"""ecommerce URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from myapp import views
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home_page.as_view(), name = 'homepage' ),
    path('signup/', views.signup_page.as_view(), name = 'signup' ),
    path('login/', views.user_login.as_view(), name = 'login' ),
    path('htmlpage/', views.html.as_view(), name = 'html' ),

# this is for choice admin what think upload    
    path('shoose_upload/', views.uplode_shoose.as_view(), name = 'shoose_upload' ),

#user click the image and check detail for the image 
    path('user_click/<int:id>', views.user_click, name = 'user_click' ),
    path('user_click_watch/<int:id>', views.user_click_watch, name = 'user_click_watch' ),
    path('user_click_mobile/<int:id>', views.user_click_mobile, name = 'user_click_mobile' ),
    path('user_click_pant/<int:id>', views.user_click_pant, name = 'user_click_pant' ),
    path('user_click_tshirt/<int:id>', views.user_click_tshirt, name = 'user_click_tshirt' ),
    path('user_click_kitchen/<int:id>', views.user_click_kitchen, name = 'user_click_kitchen' ),
    path('user_click_electronics/<int:id>', views.user_click_electronics, name = 'user_click_electronics' ),





  
# this is for upload shoose and shoose page   
    path('shoose_uplode/', views.shoose.as_view(), name = 'shoose_uplode' ),
    path('shoose_page/', views.shoose_render.as_view(), name = 'shoose_page' ),
# this is for upload watch and watch page   
    path('watch_uplode/', views.watch.as_view(), name = 'watch_uplode' ),
    path('watch_page/', views.watch_render.as_view(), name = 'watch_page' ),
# this is for upload mobile and mobile page  
    path('mobile_upload/', views.mobile.as_view(), name = 'mobile_upload' ),
    path('mobile_page/', views.mobile_render.as_view(), name = 'mobile_page' ),
# this is for upload pant and pant page  
    path('pant_uplode/', views.pant.as_view(), name = 'pant_uplode' ),
    path('pant_page/', views.pant_render.as_view(), name = 'pant_page' ),

# this is for upload tshirt and tshirt page  
    path('tshirt_uplode/', views.tshirt.as_view(), name = 'tshirt_uplode' ),
    path('tshirt_page/', views.tshirt_render.as_view(), name = 'tshirt_page' ),

# this is for upload kitchen and kitchen page  
    path('kitchen_uplode/', views.kitchen.as_view(), name = 'kitchen_uplode' ),
    path('kitchen_page/', views.kitchen_render.as_view(), name = 'kitchen_page' ),

# this is for upload electronics and electronics page  
    path('electronics_uplode/', views.electronics.as_view(), name = 'electronics_uplode' ),
    path('electronics_page/', views.electronics_render.as_view(), name = 'electronics_page' ),




]+static(settings.MEDIA_URL,document_root = settings.MEDIA_ROOT)
print(static(settings.MEDIA_URL,document_root = settings.MEDIA_ROOT))
