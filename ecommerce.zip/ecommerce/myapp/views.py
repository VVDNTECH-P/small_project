
from django.shortcuts import render
from django.views import View
from .form import user_creation_form , user_logedin_form
from django.contrib.auth import authenticate ,login,logout,update_session_auth_hash
from django.contrib import messages
from django.http import HttpResponseRedirect
from .form import shoose_image , watch_image , mobile_image ,pant_image , tshirt_image ,kitchen_image ,electronics_image
from .models import shoose_image_uplode , watch_image_uplode ,mobile_image_uplode , pant_image_uplode,tshirt_image_uplode, kitchen_image_uplode , electronics_image_uplode
# Create your views here.

# home page 
class home_page(View):
    template_name = 'home.html'

    def get(self,request):
        data = shoose_image_uplode.objects.all()
        return render(request , self.template_name , {'data' : data} )

    def post(self,request):
        return render(request , self.template_name)


# signup page 
class signup_page(View):
    template_name = 'signup.html'
    def get(self, request):
        form = user_creation_form()
        return render(request , self.template_name, {'form' : form } )
    def post(self , request):
        if 'Signup' in request.POST:
            form = user_creation_form(request.POST)
            if form.is_valid():
                form.save()
                return HttpResponseRedirect('/')
                
        else:
            print('form not valid')
        
        return render(request , self.template_name , {'form' : form }) 





class user_login(View):
    template_name = 'login.html'
    
        
    def get(self,request):
        if not request.user.is_authenticated:
            form = user_logedin_form()
            context = {'data' : form}
            print('@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@')
            return render(request , self.template_name , context)
        else:
            return HttpResponseRedirect('/homepage/')


    def post(self, request):
        user_name_of_user = request.POST['username']
        user_name_of_password = request.POST['password']
        print('*********************************')
        print()
        print(user_name_of_user)
        print(user_name_of_password)
        form = user_logedin_form(request=request,data=request.POST)
        print('********')
        print(request.POST)
        if form.is_valid():
            user = authenticate(username = user_name_of_user , password = user_name_of_password)
            print('matched')
            if user is not None:
                login(request,user)
                print('oooooooooooooooooooooooooooooooooooooooooooooooooooooo*************************************')
                return HttpResponseRedirect('/')
        else:
            print('not valid')
            form = user_logedin_form()
            return HttpResponseRedirect('/')



        return render (request , self.template_name)


#for testing 
class html(View):
    template_name = 'abc.html'

    def get(self,request):
        return render(request , self.template_name )

    def post(self,request):
        return render(request , self.template_name)



# for shoose 
class shoose(View):
    templates_name = 'product_html/shoose/shoose.html'
    def get (self , request):
        shoose_form = shoose_image()
        return render (request , self.templates_name , {'shoose_form' : shoose_form})
    def post(self , request) :

        shoose_form = shoose_image(request.POST,request.FILES)
        if shoose_form.is_valid():
            print('form favid *********************************')
            shoose_form.save()
            messages.success(request, "Uploded")
            shoose_form = shoose_image()


        else:
            print('not valid ----------------------------------')
        return render(request , self.templates_name  , {'shoose_form' : shoose_form})
class shoose_render(View):
    template_name = 'product_html/shoose/shoose1.html'
    def get(self, request):
        data = shoose_image_uplode.objects.all()
        return render(request , self.template_name , {'data' : data} )


# for watch 
class watch(View):
    templates_name = 'product_html/watch/watch.html'
    def get (self , request):
        watch_form = watch_image()
        return render (request , self.templates_name , {'watch_form' : watch_form})
    def post(self , request) :

        watch_form = watch_image(request.POST,request.FILES)
        if watch_form.is_valid():
            print('form favid *********************************')
            watch_form.save()
            messages.success(request, "Uploded")
            watch_form = watch_image()

        else:
            print('not valid ----------------------------------')
        return render(request , self.templates_name  , {'watch_form' : watch_form})
class watch_render(View):
    template_name = 'product_html/watch/watch1.html'
    def get(self, request):
        data = watch_image_uplode.objects.all()
        return render(request , self.template_name , {'data' : data} )


#for mobile 
class mobile(View):
    templates_name = 'product_html/mobile/mobile.html'
    def get (self , request):
        mobile_form = mobile_image()
        return render (request , self.templates_name , {'mobile_form' : mobile_form})
    def post(self , request) :

        mobile_form = mobile_image(request.POST,request.FILES)
        if mobile_form.is_valid():
            print('form favid *********************************')
            mobile_form.save()
            messages.success(request, "Uploded")
            mobile_form = mobile_image()

        else:
            print('not valid ----------------------------------')
        return render(request , self.templates_name  , {'watch_form' : mobile_form})
class mobile_render(View):
    template_name = 'product_html/mobile/mobile1.html'
    def get(self, request):
        data = mobile_image_uplode.objects.all()
        return render(request , self.template_name , {'data' : data} )


#for pant 
class pant(View):
    templates_name = 'product_html/pant/pant.html'
    def get (self , request):
        pant_form = pant_image()
        return render (request , self.templates_name , {'pant_form' : pant_form})
    def post(self , request) :

        pant_form = pant_image(request.POST,request.FILES)
        if pant_form.is_valid():
            print('form favid *********************************')
            pant_form.save()
            messages.success(request, "Uploded")
            pant_form = pant_image()

        else:
            print('not valid ----------------------------------')
        return render(request , self.templates_name  , {'pant_form' : pant_form})

class pant_render(View):
    template_name = 'product_html/pant/pant1.html'
    def get(self, request):
        data = pant_image_uplode.objects.all()
        return render(request , self.template_name , {'data' : data} )


#for T-shirt 
class tshirt(View):
    templates_name = 'product_html/tshirt/tshirt.html'
    def get (self , request):
        tshirt_form = tshirt_image()
        return render (request , self.templates_name , {'tshirt_form' : tshirt_form})
    def post(self , request) :

        tshirt_form = tshirt_image(request.POST,request.FILES)
        if tshirt_form.is_valid():
            print('form favid *********************************')
            tshirt_form.save()
            messages.success(request, "Uploded")
            tshirt_form = tshirt_image()

        else:
            print('not valid ----------------------------------')
        return render(request , self.templates_name  , {'tshirt_form' : tshirt_form})


class tshirt_render(View):
    template_name = 'product_html/tshirt/tshirt1.html'
    def get(self, request):
        data = tshirt_image_uplode.objects.all()
        return render(request , self.template_name , {'data' : data} )



#for Kitchen 
class kitchen(View):
    templates_name = 'product_html/kitchen/kitchen.html'
    def get (self , request):
        kitchen_form = kitchen_image()
        return render (request , self.templates_name , {'kitchen_form' : kitchen_form})
    def post(self , request) :

        kitchen_form = kitchen_image(request.POST,request.FILES)
        if kitchen_form.is_valid():
            print('form favid *********************************')
            kitchen_form.save()
            messages.success(request, "Uploded")
            kitchen_form = kitchen_image()

        else:
            print('not valid ----------------------------------')
        return render(request , self.templates_name  , {'kitchen_form' : kitchen_form})

class kitchen_render(View):
    template_name = 'product_html/kitchen/kitchen1.html'
    def get(self, request):
        data = kitchen_image_uplode.objects.all()
        return render(request , self.template_name , {'data' : data} )


#for Electronics  
class electronics(View):
    templates_name = 'product_html/electronics/electronics.html'
    def get (self , request):
        electronics_form = electronics_image()
        return render (request , self.templates_name , {'electronics_form' : electronics_form})
    def post(self , request) :

        electronics_form = electronics_image(request.POST,request.FILES)
        if electronics_form.is_valid():
            print('form favid *********************************')
            electronics_form.save()
            messages.success(request, "Uploded")
            electronics_form = electronics_image()

        else:
            print('not valid ----------------------------------')
        return render(request , self.templates_name  , {'electronics_form' : electronics_form})


class electronics_render(View):
    template_name = 'product_html/electronics/electronics1.html'
    def get(self, request):
        data = electronics_image_uplode.objects.all()
        return render(request , self.template_name , {'data' : data} )





 # click one image its render html page 
def user_click (request , id ):
    fetch_data = shoose_image_uplode.objects.get(pk = id)

    return render(request , 'product_html/shoose/user_click.html', {'fetch_data' : fetch_data})

def user_click_watch (request , id ):
    fetch_data = watch_image_uplode.objects.get(pk = id)

    return render(request , 'product_html/watch/user_click_watch.html', {'fetch_data' : fetch_data})

def user_click_mobile (request , id ):
    fetch_data = mobile_image_uplode.objects.get(pk = id)

    return render(request , 'product_html/mobile/user_click_mobile.html', {'fetch_data' : fetch_data})

def user_click_pant (request , id ):
    fetch_data = pant_image_uplode.objects.get(pk = id)

    return render(request , 'product_html/pant/user_click_pant.html', {'fetch_data' : fetch_data})
def user_click_tshirt (request , id ):
    fetch_data = tshirt_image_uplode.objects.get(pk = id)

    return render(request , 'product_html/tshirt/user_click_tshirt.html', {'fetch_data' : fetch_data})
def user_click_kitchen (request , id ):
    fetch_data = kitchen_image_uplode.objects.get(pk = id)

    return render(request , 'product_html/kitchen/user_click_kitchen.html', {'fetch_data' : fetch_data})
def user_click_electronics (request , id ):
    fetch_data = electronics_image_uplode.objects.get(pk = id)

    return render(request , 'product_html/electronics/user_click_electronics.html', {'fetch_data' : fetch_data})

class uplode_shoose (View):
    template_name = 'uplode_choose.html'
    def get (self, request):
        return render(request , self.template_name)