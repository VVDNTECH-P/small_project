
from tkinter import Widget
from django import forms
from .models import shoose_image_uplode , watch_image_uplode , mobile_image_uplode ,pant_image_uplode ,tshirt_image_uplode ,kitchen_image_uplode ,electronics_image_uplode
from django.contrib.auth.forms import UserCreationForm , AuthenticationForm , UsernameField
from django.contrib.auth.models import User

class user_creation_form(UserCreationForm):
    password1=forms.CharField(label='Password',widget=forms.PasswordInput(attrs={'class': 'form-control' , 'placeholder': 'Password'}))
    password2=forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': '(again)Password' }))
    class Meta:
        model = User
        fields = ['username' , 'first_name' , 'last_name' , 'email' ]

        widgets= {'username':forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Username' }),
        'last_name':forms.TextInput(attrs={'class': 'form-control' , 'placeholder': 'first name '}),
        'first_name':forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Last_name '}),
        'email':forms.EmailInput(attrs={'class': 'form-control' , 'placeholder': 'Email' }),


}

class user_logedin_form(AuthenticationForm):
    username=UsernameField(widget=forms.TextInput(attrs={'autofocus':True ,'class': 'form-control' }))
    password=forms.CharField(strip=False,widget=forms.PasswordInput(attrs={'autocomplete':'current-possword' ,'class': 'form-control' }))



class shoose_image(forms.ModelForm):
    class Meta:
        model = shoose_image_uplode
        fields = ['product_name' , 'before_discount' ,'after_discount', 'shoose_image']

        widgets= {'product_name':forms.TextInput(attrs={'class': 'form-control','placeholder': 'Product name'}),
        'before_discount':forms.TextInput(attrs={'class': 'form-control','placeholder': 'Before_discount'}),
        'after_discount':forms.TextInput(attrs={'class': 'form-control','placeholder': 'After discount'}),

}


class watch_image(forms.ModelForm):
    class Meta:
        model = watch_image_uplode
        fields = ['product_name' , 'before_discount' ,'after_discount', 'watch_image']

        widgets= {'product_name':forms.TextInput(attrs={'class': 'form-control','placeholder': 'Product name'}),
        'before_discount':forms.TextInput(attrs={'class': 'form-control','placeholder': 'Before_discount'}),
        'after_discount':forms.TextInput(attrs={'class': 'form-control','placeholder': 'After discount'}),

}


class mobile_image(forms.ModelForm):
    class Meta:
        model = mobile_image_uplode
        fields = ['product_name' , 'before_discount' ,'after_discount', 'mobile_image']

        widgets= {'product_name':forms.TextInput(attrs={'class': 'form-control','placeholder': 'Product name'}),
        'before_discount':forms.TextInput(attrs={'class': 'form-control','placeholder': 'Before_discount'}),
        'after_discount':forms.TextInput(attrs={'class': 'form-control','placeholder': 'After discount'}),

}

class pant_image(forms.ModelForm):
    class Meta:
        model = pant_image_uplode
        fields = ['product_name' , 'before_discount' ,'after_discount', 'pant_image']

        widgets= {'product_name':forms.TextInput(attrs={'class': 'form-control','placeholder': 'Product name'}),
        'before_discount':forms.TextInput(attrs={'class': 'form-control','placeholder': 'Before_discount'}),
        'after_discount':forms.TextInput(attrs={'class': 'form-control','placeholder': 'After discount'}),

}
class tshirt_image(forms.ModelForm):
    class Meta:
        model = tshirt_image_uplode
        fields = ['product_name' , 'before_discount' ,'after_discount', 'tshirt_image']

        widgets= {'product_name':forms.TextInput(attrs={'class': 'form-control','placeholder': 'Product name'}),
        'before_discount':forms.TextInput(attrs={'class': 'form-control','placeholder': 'Before_discount'}),
        'after_discount':forms.TextInput(attrs={'class': 'form-control','placeholder': 'After discount'}),

}


class kitchen_image(forms.ModelForm):
    class Meta:
        model = kitchen_image_uplode
        fields = ['product_name' , 'before_discount' ,'after_discount', 'kitchen_image']

        widgets= {'product_name':forms.TextInput(attrs={'class': 'form-control','placeholder': 'Product name'}),
        'before_discount':forms.TextInput(attrs={'class': 'form-control','placeholder': 'Before_discount'}),
        'after_discount':forms.TextInput(attrs={'class': 'form-control','placeholder': 'After discount'}),

}
class electronics_image(forms.ModelForm):
    class Meta:
        model = electronics_image_uplode
        fields = ['product_name' , 'before_discount' ,'after_discount', 'electronics_image']

        widgets= {'product_name':forms.TextInput(attrs={'class': 'form-control','placeholder': 'Product name'}),
        'before_discount':forms.TextInput(attrs={'class': 'form-control','placeholder': 'Before_discount'}),
        'after_discount':forms.TextInput(attrs={'class': 'form-control','placeholder': 'After discount'}),

}
