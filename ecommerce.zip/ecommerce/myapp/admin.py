
from django.contrib import admin

# Register your models here.
from .models import shoose_image_uplode , watch_image_uplode ,  mobile_image_uplode , pant_image_uplode, tshirt_image_uplode,kitchen_image_uplode, electronics_image_uplode


@admin.register(shoose_image_uplode)
class adminshoose_image_uplode(admin.ModelAdmin):
    list_display = ['id' , 'product_name' , 'before_discount' ,'after_discount','shoose_image']

@admin.register(watch_image_uplode)
class adminwatch_image_uplode(admin.ModelAdmin):
    list_display = ['id' , 'product_name' , 'before_discount' ,'after_discount','watch_image']
    

@admin.register(mobile_image_uplode)
class adminmobile_image_uplode(admin.ModelAdmin):
    list_display = ['id' , 'product_name' , 'before_discount' ,'after_discount','mobile_image']
        
@admin.register(pant_image_uplode)
class adminpant_image_uplode(admin.ModelAdmin):
    list_display = ['id' , 'product_name' , 'before_discount' ,'after_discount','pant_image']
        
@admin.register(tshirt_image_uplode)
class admintshirt_image_uplode(admin.ModelAdmin):
    list_display = ['id' , 'product_name' , 'before_discount' ,'after_discount','tshirt_image']
        
@admin.register(kitchen_image_uplode)
class adminkitchen_image_uplode(admin.ModelAdmin):
    list_display = ['id' , 'product_name' , 'before_discount' ,'after_discount','kitchen_image']

@admin.register(electronics_image_uplode)
class adminkitchen_image_uplode(admin.ModelAdmin):
    list_display = ['id' , 'product_name' , 'before_discount' ,'after_discount','electronics_image']
        