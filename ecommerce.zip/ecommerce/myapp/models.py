from django.db import models

# Create your models here.


class shoose_image_uplode(models.Model):
    product_name = models.CharField(max_length=50)
    before_discount = models.CharField(max_length=10)
    after_discount = models.CharField(max_length=10)
    shoose_image =  models.ImageField(upload_to = 'uplode_image')

class watch_image_uplode(models.Model):
    product_name = models.CharField(max_length=50)
    before_discount = models.CharField(max_length=10)
    after_discount = models.CharField(max_length=10)
    watch_image =  models.ImageField(upload_to = 'uplode_image')

class mobile_image_uplode(models.Model):
    product_name = models.CharField(max_length=50)
    before_discount = models.CharField(max_length=10)
    after_discount = models.CharField(max_length=10)
    mobile_image =  models.ImageField(upload_to = 'uplode_image')

class pant_image_uplode(models.Model):
    product_name = models.CharField(max_length=50)
    before_discount = models.CharField(max_length=10)
    after_discount = models.CharField(max_length=10)
    pant_image =  models.ImageField(upload_to = 'uplode_image')

class tshirt_image_uplode(models.Model):
    product_name = models.CharField(max_length=50)
    before_discount = models.CharField(max_length=10)
    after_discount = models.CharField(max_length=10)
    tshirt_image =  models.ImageField(upload_to = 'uplode_image')

class kitchen_image_uplode(models.Model):
    product_name = models.CharField(max_length=50)
    before_discount = models.CharField(max_length=10)
    after_discount = models.CharField(max_length=10)
    kitchen_image =  models.ImageField(upload_to = 'uplode_image')

class electronics_image_uplode(models.Model):
    product_name = models.CharField(max_length=50)
    before_discount = models.CharField(max_length=10)
    after_discount = models.CharField(max_length=10)
    electronics_image =  models.ImageField(upload_to = 'uplode_image')
