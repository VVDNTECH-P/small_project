
from django.db import models

# Create your models here.

class admin_post(models.Model):
    title = models.CharField(max_length= 50)
    desc = models.CharField(max_length=200)
    image = models.ImageField(upload_to = 'uplode_image')


class comments(models.Model):
    user = models.CharField(max_length=50)
    user_id = models.IntegerField()
    message =  models.CharField(max_length=200)

